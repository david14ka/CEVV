package com.davidkazad.cevv.utils;

public class Constants {

    public static final String TAG = "song tag";

}
